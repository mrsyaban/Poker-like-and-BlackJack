#include "GameEngine/GameEngine.hpp"
#include "IO/IO.hpp"

int main(){
    GameEngine g;
    g.start();
}