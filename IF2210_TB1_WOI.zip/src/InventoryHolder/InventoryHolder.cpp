#include "InventoryHolder.hpp"
template class InventoryHolder<Card>;
template class InventoryHolder<Ability*>;